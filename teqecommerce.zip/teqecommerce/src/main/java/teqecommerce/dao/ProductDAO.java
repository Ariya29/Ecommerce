package teqecommerce.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import teqecommerce.model.Product;

public class ProductDAO {

	public void addNewProduct(Product product) {

		Transaction transaction = null;
		Session session = null;
		
		try {
			session = HibernateConfiguration.getSessionFactory().openSession();
			transaction = session.beginTransaction();
			
			session.save(product);
			
			transaction.commit();
		} catch (Exception e) {
			if (null != transaction)
				transaction.rollback();
		} finally {
			session.close();
			session = null;
			transaction = null;
		}
	}
}
