package teqecommerce.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;

import teqecommerce.model.User;

@Component
public class UserDAO {
	
	public void addNewUser(User user) {

		Transaction transaction = null;
		Session session = null;
		
		try {
			session = HibernateConfiguration.getSessionFactory().openSession();
			transaction = session.beginTransaction();
			
			session.save(user);
			
			transaction.commit();
		} catch (Exception e) {
			if (null != transaction)
				transaction.rollback();
			e.printStackTrace();
		} finally {
			session = null;
			transaction = null;
		}
	}
}
