package teqecommerce.dao;

public class DAO {

}
